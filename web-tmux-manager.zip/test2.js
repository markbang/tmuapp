import { spawn } from 'child_process';

const py = spawn('python3', ['pty_bridge.py']);

py.stdout.on('data', (buf) => {
  // read protocol
  // could span multiple chunks so a real implementation needs a buffer, but let's just log the first chunk
  console.log('Got python data:', buf.length, buf.slice(0, 10));
  if (buf[0] === 0) {
    const len = buf.readUInt32BE(1);
    const data = buf.slice(5, 5 + len);
    console.log('PTY out:', data.toString());
  }
});

py.stderr.on('data', d => console.log('Err:', d.toString()));
py.on('close', c => console.log('Closed', c));

// send ls
const cmd = Buffer.from('ls\n');
const msg = Buffer.alloc(5 + cmd.length);
msg[0] = 0;
msg.writeUInt32BE(cmd.length, 1);
cmd.copy(msg, 5);

setTimeout(() => {
  py.stdin.write(msg);
}, 500);

setTimeout(() => {
  py.kill();
}, 1000);
