import express from "express";
import http from "http";
import path from "path";
import { Server } from "socket.io";
import { spawn, ChildProcess } from "child_process";
import { createServer as createViteServer } from "vite";
import fs from "fs";

const PORT = 3000;
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

app.use(express.json());

interface TerminalSession {
  id: string;
  name: string;
  process: ChildProcess;
  history: Buffer;
}

const sessions = new Map<string, TerminalSession>();

function createSession(name: string) {
  const id = Math.random().toString(36).substring(2, 9);
  const py = spawn('python3', [path.join(process.cwd(), 'pty_bridge.py')]);

  py.on('error', (err) => {
    console.error(`Failed to spawn python process for session ${id}:`, err);
  });

  const session: TerminalSession = {
    id,
    name,
    process: py,
    history: Buffer.alloc(0)
  };

  let buffer = Buffer.alloc(0);

  py.stdout?.on('data', (data) => {
    buffer = Buffer.concat([buffer, data]);
    while (buffer.length >= 5) {
      if (buffer[0] === 0) {
        const len = buffer.readUInt32BE(1);
        if (buffer.length >= 5 + len) {
          const chunk = buffer.slice(5, 5 + len);
          buffer = buffer.slice(5 + len);
          
          // Store history (up to last 16KB to prevent memory leak)
          session.history = Buffer.concat([session.history, chunk]);
          if (session.history.length > 16384) {
            session.history = session.history.slice(session.history.length - 16384);
          }
          
          // Broadcast to anyone connected to this session
          io.to(id).emit('data', chunk.toString('utf-8'));
        } else {
          break;
        }
      } else {
        // Unknown type, discard header
        buffer = buffer.slice(1);
      }
    }
  });

  py.on('close', () => {
    sessions.delete(id);
    io.emit('sessions', getSessionsList());
  });

  sessions.set(id, session);
  io.emit('sessions', getSessionsList());
  return session;
}

function getSessionsList() {
  return Array.from(sessions.values()).map(s => ({
    id: s.id,
    name: s.name
  }));
}

// API Routes
app.get("/api/sessions", (req, res) => {
  res.json(getSessionsList());
});

app.post("/api/sessions", (req, res) => {
  const { name } = req.body;
  const session = createSession(name || `Window ${sessions.size + 1}`);
  res.json({ id: session.id, name: session.name });
});

app.delete("/api/sessions/:id", (req, res) => {
  const session = sessions.get(req.params.id);
  if (session) {
    session.process.kill();
    sessions.delete(req.params.id);
  }
  res.json({ success: true });
});

io.on("connection", (socket) => {
  socket.on("join", (id) => {
    const session = sessions.get(id);
    if (session) {
      socket.join(id);
      socket.emit("data", session.history.toString('utf-8'));
    }
  });

  socket.on("data", (id, data) => {
    const session = sessions.get(id);
    if (session && session.process.stdin) {
      const buf = Buffer.from(data, 'utf-8');
      const msg = Buffer.alloc(5 + buf.length);
      msg[0] = 0;
      msg.writeUInt32BE(buf.length, 1);
      buf.copy(msg, 5);
      session.process.stdin.write(msg);
    }
  });

  socket.on("resize", (id, cols, rows) => {
    const session = sessions.get(id);
    if (session && session.process.stdin) {
      const msg = Buffer.alloc(5);
      msg[0] = 1;
      msg.writeUInt16BE(rows, 1);
      msg.writeUInt16BE(cols, 3);
      session.process.stdin.write(msg);
    }
  });
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
