import pty
import os
import sys
import struct
import fcntl
import termios
import threading

pid, master_fd = pty.fork()

if pid == 0:
    os.environ['TERM'] = 'xterm-256color'
    os.execv('/bin/bash', ['/bin/bash'])
else:
    def set_winsize(fd, row, col):
        winsize = struct.pack("HHHH", row, col, 0, 0)
        fcntl.ioctl(fd, termios.TIOCSWINSZ, winsize)

    def read_from_pty():
        try:
            while True:
                data = os.read(master_fd, 4096)
                if not data:
                    break
                # write out type 0 header so node knows it's data
                if sys.stdout is not None:
                    sys.stdout.buffer.write(b'\x00' + struct.pack(">I", len(data)) + data)
                    sys.stdout.buffer.flush()
        except OSError:
            pass
        finally:
            os._exit(0)
    
    t = threading.Thread(target=read_from_pty, daemon=True)
    t.start()

    try:
        while True:
            header = sys.stdin.buffer.read(1)
            if not header:
                break
            msg_type = header[0]
            if msg_type == 0:
                length_bytes = sys.stdin.buffer.read(4)
                if len(length_bytes) < 4: break
                length = struct.unpack(">I", length_bytes)[0]
                data = sys.stdin.buffer.read(length)
                os.write(master_fd, data)
            elif msg_type == 1:
                resize_bytes = sys.stdin.buffer.read(4)
                if len(resize_bytes) < 4: break
                rows, cols = struct.unpack(">HH", resize_bytes)
                set_winsize(master_fd, rows, cols)
    except Exception:
        pass
    finally:
        os._exit(0)
