import { useState, useEffect } from "react";
import Dashboard from "./components/Dashboard";
import TerminalWindow from "./components/TerminalWindow";

export type Session = {
  id: string;
  name: string;
};

export default function App() {
  const [sessions, setSessions] = useState<Session[]>([]);
  const [activeSession, setActiveSession] = useState<string | null>(null);

  useEffect(() => {
    fetchSessions();
  }, [activeSession]); // Refresh when coming back to dashboard

  const fetchSessions = async () => {
    try {
      const res = await fetch("/api/sessions");
      if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
      const data = await res.json();
      setSessions(data);
    } catch (e: any) {
      console.error("Failed to fetch sessions:", e);
    }
  };

  const createSession = async () => {
    try {
      const res = await fetch("/api/sessions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
      const data = await res.json();
      setActiveSession(data.id);
    } catch (e: any) {
      console.error("Failed to create session:", e);
    }
  };

  const deleteSession = async (id: string) => {
    try {
      const res = await fetch(`/api/sessions/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
      await fetchSessions();
    } catch (e: any) {
      console.error("Failed to delete session:", e);
    }
  };

  return (
    <div className="h-screen w-full bg-[#0F1117] text-slate-300 font-sans flex flex-col overflow-hidden">
      {activeSession ? (
        <TerminalWindow 
          sessionId={activeSession} 
          onClose={() => setActiveSession(null)} 
        />
      ) : (
        <Dashboard 
          sessions={sessions}
          onCreate={createSession}
          onDelete={deleteSession}
          onSelect={setActiveSession}
        />
      )}
    </div>
  );
}
