import { useEffect, useRef } from "react";
import { Terminal } from "@xterm/xterm";
import { FitAddon } from "@xterm/addon-fit";
import "@xterm/xterm/css/xterm.css";
import { io, Socket } from "socket.io-client";
import { ChevronLeft, Terminal as TerminalIcon } from "lucide-react";

export default function TerminalWindow({ 
  sessionId, 
  onClose 
}: { 
  sessionId: string,
  onClose: () => void
}) {
  const terminalRef = useRef<HTMLDivElement>(null);
  const termRef = useRef<Terminal | null>(null);
  const socketRef = useRef<Socket | null>(null);
  const fitAddonRef = useRef<FitAddon | null>(null);

  useEffect(() => {
    if (!terminalRef.current) return;

    // Initialize Terminal
    const term = new Terminal({
      cursorBlink: true,
      fontFamily: '"Courier New", Courier, monospace',
      fontSize: 14,
      theme: {
        background: '#050505',
        foreground: '#cbd5e1',
        cursor: '#4ade80',
        selectionBackground: 'rgba(79, 70, 229, 0.3)',
      }
    });

    const fitAddon = new FitAddon();
    term.loadAddon(fitAddon);
    term.open(terminalRef.current);
    termRef.current = term;
    fitAddonRef.current = fitAddon;

    // We can use a ResizeObserver to wait for the element to have dimensions before fitting
    const resizeObserver = new ResizeObserver(() => {
      handleResize();
    });
    resizeObserver.observe(terminalRef.current);

    // Initial check is deferred to resize observer, but we still handle it defensively
    const safeFit = () => {
      try {
        if (terminalRef.current && terminalRef.current.clientWidth > 0) {
          const dims = fitAddon.proposeDimensions();
          if (dims) {
            fitAddon.fit();
            return dims;
          }
        }
      } catch (err) {
        console.warn("Safe fit error:", err);
      }
      return null;
    };

    safeFit();

    // Connect WebSocket
    const socket = io();
    socketRef.current = socket;

    socket.on("connect", () => {
      socket.emit("join", sessionId);
    });

    socket.on("data", (data: string) => {
      term.write(data);
    });

    term.onData((data) => {
      socket.emit("data", sessionId, data);
    });

    const handleResize = () => {
      const dims = safeFit();
      if (dims && socket.connected) {
         socket.emit("resize", sessionId, dims.cols, dims.rows);
      }
    };

    window.addEventListener("resize", handleResize);
    // Initial resize to sync server pty size
    setTimeout(handleResize, 100);

    return () => {
      resizeObserver.disconnect();
      window.removeEventListener("resize", handleResize);
      socket.disconnect();
      term.dispose();
    };
  }, [sessionId]);

  return (
    <div className="h-screen flex flex-col bg-[#0F1117] text-slate-300">
      <header className="h-14 flex-shrink-0 flex items-center justify-between px-6 bg-[#16191F] border-b border-[#2D333F]">
        <div className="flex items-center gap-6">
          <button 
            onClick={onClose}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1E222A] hover:bg-[#2D333F] text-white text-xs font-mono rounded transition-colors border border-[#2D333F]"
          >
            <ChevronLeft className="w-4 h-4" />
            BACK
          </button>
          <div className="h-6 w-[1px] bg-slate-700"></div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
            <span className="font-bold tracking-tight text-white uppercase">Tmux Terminal</span>
          </div>
        </div>
        <div className="flex items-center gap-4 text-[11px] font-mono text-slate-400">
          <span className="text-indigo-400">Session:</span> {sessionId}
        </div>
      </header>
      
      <div className="flex-1 w-full bg-[#050505] overflow-hidden relative">
        <div className="absolute top-0 left-0 w-full h-full p-4" ref={terminalRef} />
      </div>
    </div>
  );
}
