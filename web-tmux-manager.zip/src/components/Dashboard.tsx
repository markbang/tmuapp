import { TerminalSquare, Plus, Trash2, Code2 } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useState, useEffect } from "react";
import type { Session } from "../App";

export default function Dashboard({ 
  sessions, 
  onCreate, 
  onDelete, 
  onSelect 
}: { 
  sessions: Session[], 
  onCreate: () => void,
  onDelete: (id: string) => void,
  onSelect: (id: string) => void
}) {
  const [cpuUsage, setCpuUsage] = useState(42);
  const [memUsage, setMemUsage] = useState(68);

  useEffect(() => {
    const interval = setInterval(() => {
      setCpuUsage(prev => Math.min(100, Math.max(0, prev + (Math.random() * 10 - 5))));
      setMemUsage(prev => Math.min(100, Math.max(0, prev + (Math.random() * 4 - 2))));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="h-full flex flex-col bg-[#0F1117] text-slate-300 overflow-hidden select-none w-full">
      <header className="h-14 flex flex-shrink-0 items-center justify-between px-6 bg-[#16191F] border-b border-[#2D333F]">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]"></div>
            <span className="font-bold tracking-tight text-white uppercase">Tmux Web Panel</span>
          </div>
          <div className="h-6 w-[1px] bg-slate-700"></div>
          <div className="text-xs font-mono uppercase tracking-widest text-slate-500">
            Manager Dash
          </div>
        </div>
        <div className="flex items-center gap-8 text-[11px] font-mono">
          <div className="hidden sm:flex flex-col items-end">
            <span className="text-slate-400">CPU</span>
            <div className="w-24 h-1 bg-[#1A1D23] mt-1 relative">
              <motion.div 
                className="absolute top-0 left-0 h-full bg-indigo-500"
                animate={{ width: `${cpuUsage}%` }}
                transition={{ type: "tween", ease: "linear", duration: 2 }}
              />
            </div>
          </div>
          <div className="hidden sm:flex flex-col items-end">
            <span className="text-slate-400">MEM</span>
            <div className="w-24 h-1 bg-[#1A1D23] mt-1 relative">
              <motion.div 
                className="absolute top-0 left-0 h-full bg-indigo-500"
                animate={{ width: `${memUsage}%` }}
                transition={{ type: "tween", ease: "linear", duration: 2 }}
              />
            </div>
          </div>
          <button 
             onClick={onCreate}
             className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded transition-colors text-xs"
           >
             <Plus className="w-4 h-4" />
             New Window
           </button>
        </div>
      </header>

      <main className="flex-1 p-6 overflow-y-auto">
        {sessions.length === 0 ? (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="h-full flex flex-col items-center justify-center text-slate-500"
          >
            <Code2 className="w-16 h-16 mb-4 text-slate-700" />
            <h2 className="text-xl font-medium text-slate-300 uppercase tracking-widest font-mono">No active windows</h2>
            <p className="mt-2 text-xs text-slate-500 font-mono">Create a new window to get started.</p>
            <button 
             onClick={onCreate}
             className="mt-6 flex items-center gap-1.5 px-4 py-2 bg-[#1E222A] border border-[#2D333F] hover:border-indigo-500 text-white font-mono text-xs rounded transition-all cursor-pointer hover:shadow-[0_0_15px_rgba(79,70,229,0.2)]"
           >
             <Plus className="w-4 h-4" />
             CREATE_WINDOW
           </button>
          </motion.div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 content-start">
            <AnimatePresence>
              {sessions.map((session, index) => (
                <motion.div 
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.3, delay: index * 0.05 }}
                  key={session.id} 
                  className="bg-[#050505] border border-[#2D333F] hover:border-indigo-500 hover:shadow-[0_0_15px_rgba(79,70,229,0.2)] rounded-lg flex flex-col overflow-hidden transition-all duration-200 cursor-pointer group h-[220px]"
                  onClick={() => onSelect(session.id)}
                >
                  <div className="bg-[#1E222A] font-mono px-3 py-1.5 flex justify-between items-center border-b border-[#2D333F] transition-colors relative overflow-hidden">
                     {/* subtle glow effect on hover */}
                    <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-indigo-500/0 to-transparent group-hover:via-indigo-500/50 transition-all duration-500" />
                    
                    <span className="text-xs text-white truncate max-w-[120px]">{index}: {session.name}*</span>
                    <div className="flex items-center gap-3">
                      <span className="text-[10px] px-1.5 py-0.5 bg-indigo-600 rounded text-white font-sans uppercase">Active</span>
                      <button 
                        onClick={(e) => { e.stopPropagation(); onDelete(session.id); }}
                        className="text-slate-500 hover:text-red-400 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                  <div className="p-4 flex-1 font-mono text-sm leading-relaxed text-slate-400 flex flex-col bg-transparent relative overflow-hidden">
                    <div className="absolute top-2 right-2 text-[10px] text-slate-600">ID: {session.id}</div>
                    
                    <div className="flex gap-2 text-xs">
                      <span className="text-indigo-400 font-bold">root@prod</span>:<span className="text-blue-400">~</span>$ ls -la
                    </div>
                    <div className="text-xs opacity-70">
                      <div>total 24</div>
                      <div>drwxr-xr-x 2 root root 4096</div>
                      <div>-rw-r--r-- 1 root root  220</div>
                    </div>
                    <div className="mt-2 flex gap-2 text-xs">
                      <span className="text-indigo-400 font-bold">root@prod</span>:<span className="text-blue-400">~</span>$ <span className="w-2 h-4 bg-green-400 inline-block animate-pulse align-middle"></span>
                    </div>
                    <div className="flex-1"></div>
                    <div className="text-slate-600">~</div>
                    <div className="text-slate-600">~</div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
            
            <motion.div 
              layout
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: sessions.length * 0.05 }}
              className="bg-transparent border border-dashed border-[#2D333F] hover:border-indigo-500 rounded-lg flex flex-col overflow-hidden opacity-40 hover:opacity-100 transition-all cursor-pointer h-[220px]"
              onClick={onCreate}
            >
              <div className="p-4 flex-1 flex flex-col items-center justify-center gap-3">
                <div className="w-10 h-10 border-2 border-slate-700 group-hover:border-indigo-400 rounded-full flex items-center justify-center text-2xl font-light text-slate-600 group-hover:text-indigo-400 shadow-[0_0_0_rgba(79,70,229,0)] group-hover:shadow-[0_0_15px_rgba(79,70,229,0.3)] transition-all">
                  +
                </div>
                <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400 group-hover:text-indigo-300">Create Window</span>
              </div>
            </motion.div>
          </div>
        )}
      </main>
      
      {sessions.length > 0 && (
        <footer className="h-8 flex-shrink-0 px-4 bg-[#1E222A] border-t border-[#2D333F] flex items-center text-[10px] font-mono text-slate-400">
          <div className="flex gap-4 overflow-x-auto whitespace-nowrap scrollbar-hide">
             {sessions.map((session, index) => (
                <div key={session.id} className="cursor-pointer hover:text-white transition-colors flex items-center gap-1" onClick={() => onSelect(session.id)}>
                   <span className="text-indigo-400">[{index}]</span> <span>{session.name}*</span>
                </div>
             ))}
          </div>
          <div className="flex-1"></div>
          <div className="flex gap-4 ml-4">
             <span className="hidden sm:inline">"Ubuntu 22.04"</span>
             <span>14:42:01</span>
             <span className="text-indigo-400 font-bold bg-[#2D333F] px-1.5 py-0.5 rounded text-[9px] tracking-wider">CTRL-B</span>
          </div>
        </footer>
      )}
    </div>
  );
}
