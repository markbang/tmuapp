import pty
import os
print("pty available!")
