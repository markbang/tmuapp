import fetch from 'node-fetch'; // No, fetch is built-in in node 22
fetch('http://localhost:3000/api/sessions').then(r => r.json()).then(console.log).catch(console.error);
