import { execSync } from 'child_process';
try {
  console.log(execSync('tmux -V').toString());
} catch (e) {
  console.log('tmux not installed:', e);
}
try {
  console.log(execSync('make -v').toString());
} catch (e) {
  console.log('make not installed');
}
try {
  console.log(execSync('python3 -V').toString());
} catch (e) {
  console.log('python3 not installed');
}
